using namespace  std;
int main()
{
    int i;
    for (i = 0;i<10000; i++)
    {
        printf("%c\n", 1);
      
    }
    cin.get();
    return 0;
}