#include <iostream>

using namespace std;

int main()
{
  
    char ch;
    cin >> ch;
    cout << "The ASCCI value is " << (int)ch<<endl;
   
    
    
}