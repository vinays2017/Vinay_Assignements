#include <iostream>
#include <stdio.h>
#include <math.h>
using namespace std;

int main()
{
  
    int num1, num2;
    int sum;
    cin >> num1 >> num2;
    sum = num1 + num2;
    cout << sum << endl;
    cout << num1 + num2;   
}